#check oracle SID 
su - oracle -c 'nohup /veeamscript/orcl1/rman_arch_backup_orcl1.sh'
