su - oracle -c 'nohup /veeamscript/orcl1/rman_incr_backup_orcl1.sh'
