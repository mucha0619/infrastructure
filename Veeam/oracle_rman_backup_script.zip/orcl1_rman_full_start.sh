su - oracle -c 'nohup /veeamscript/orcl1/rman_full_backup_orcl1.sh'
